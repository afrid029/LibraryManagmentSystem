<?php
// $db = mysqli_connect('localhost', 'root', '', 'lm-cvhth');
$db = mysqli_connect('localhost', 'rmlrkp20_library_root', 'aC2K9Vgwoi!V', 'rmlrkp20_library_cv');
?>